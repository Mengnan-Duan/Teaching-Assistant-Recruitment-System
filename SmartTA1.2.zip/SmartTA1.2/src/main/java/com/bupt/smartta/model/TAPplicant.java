package com.bupt.smartta.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class TAPplicant implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;
    private String name;
    private String email;
    private String yearOfStudy;
    private double gpa;
    private List<String> skills;
    private int hoursAvailable;
    private String cvFileName;
    private String createdAt;

    public TAPplicant() {
        this.skills = new ArrayList<>();
    }

    public TAPplicant(String id, String name, String email, String yearOfStudy,
                      double gpa, List<String> skills, int hoursAvailable) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.yearOfStudy = yearOfStudy;
        // 新增：GPA范围校验（0-4.0）
        this.gpa = (gpa >= 0 && gpa <= 4.0) ? gpa : 0.0;
        this.skills = skills != null ? skills : new ArrayList<>();
        // 新增：可用时长非负校验
        this.hoursAvailable = Math.max(hoursAvailable, 0);
        this.createdAt = java.time.LocalDate.now().toString();
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getYearOfStudy() { return yearOfStudy; }
    public void setYearOfStudy(String yearOfStudy) { this.yearOfStudy = yearOfStudy; }
    
    // 新增：setGpa时增加范围校验
    public double getGpa() { return gpa; }
    public void setGpa(double gpa) { 
        this.gpa = (gpa >= 0 && gpa <= 4.0) ? gpa : 0.0;
    }
    
    public List<String> getSkills() { return skills; }
    public void setSkills(List<String> skills) { this.skills = skills; }
    
    // 新增：setHoursAvailable时增加非负校验
    public int getHoursAvailable() { return hoursAvailable; }
    public void setHoursAvailable(int hoursAvailable) { 
        this.hoursAvailable = Math.max(hoursAvailable, 0);
    }
    
    public String getCvFileName() { return cvFileName; }
    public void setCvFileName(String cvFileName) { this.cvFileName = cvFileName; }
    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }

    public int getMatchedSkillCount(List<String> requiredSkills) {
        if (requiredSkills == null || requiredSkills.isEmpty()) {
            return 0; // 新增：空值校验，避免NPE
        }
        int count = 0;
        for (String req : requiredSkills) {
            String trimmedReq = req.trim();
            if (trimmedReq.isEmpty()) continue; // 新增：跳过空的必填技能
            for (String has : skills) {
                if (has != null && has.equalsIgnoreCase(trimmedReq)) {
                    count++;
                    break;
                }
            }
        }
        return count;
    }

    public double computeAIScore(List<String> requiredSkills, int positionHours) {
        // 优化：处理必填技能为空、positionHours为0的边界情况
        int reqCount = (requiredSkills == null) ? 0 : requiredSkills.size();
        double skillScore = reqCount > 0
            ? ((double) getMatchedSkillCount(requiredSkills) / reqCount) * 100 : 0;
        
        double gpaScore = (gpa / 4.0) * 100;
        
        // 优化：用positionHours替代固定20，避免硬编码；同时处理positionHours为0的情况
        double availScore = positionHours > 0 
            ? Math.min(((double) hoursAvailable / positionHours) * 100, 100) 
            : 0;
        
        return Math.round(0.4 * skillScore + 0.3 * gpaScore + 0.3 * availScore);
    }

    // 新增：实用方法 - 返回格式化的申请人信息（方便日志/页面展示）
    public String getFormattedInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append("TA申请人信息：\n")
          .append("ID：").append(id).append("\n")
          .append("姓名：").append(name).append("\n")
          .append("邮箱：").append(email).append("\n")
          .append("年级：").append(yearOfStudy).append("\n")
          .append("GPA：").append(String.format("%.2f", gpa)).append("\n")
          .append("掌握技能：").append(String.join(", ", skills)).append("\n")
          .append("每周可用时长：").append(hoursAvailable).append("小时\n")
          .append("创建时间：").append(createdAt);
        return sb.toString();
    }
}